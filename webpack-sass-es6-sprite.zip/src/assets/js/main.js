//Applications
var Applications = {};

Applications.init = () => {
	console.log('initalize');
};

Applications.init();
