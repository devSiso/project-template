!function(window) {
	'use strict';

	var Project = {};

	Project.init = function() {
		// variables
		var routes = window.Routes;

		// methods
		routes.init();
	};

	Project.init();
}(window);
