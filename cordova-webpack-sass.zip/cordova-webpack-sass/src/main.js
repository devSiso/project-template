// Sass
require('./assets/sass/main.sass');

// JS
require('./assets/js/main.js');
